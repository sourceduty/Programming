document.addEventListener('DOMContentLoaded', () => {
    const startButton = document.getElementById('startButton');
    const notepad = document.getElementById('notepad');
    let colorIndex = 0;
    const colors = ['color1', 'color2', 'color3'];

    startButton.addEventListener('click', () => {
        startButton.classList.remove(colors[colorIndex]);
        colorIndex = (colorIndex + 1) % colors.length;
        startButton.classList.add(colors[colorIndex]);

        if (!notepad.classList.contains('visible')) {
            notepad.classList.add('visible');
        } else {
            notepad.classList.remove('visible');
        }
    });
});
