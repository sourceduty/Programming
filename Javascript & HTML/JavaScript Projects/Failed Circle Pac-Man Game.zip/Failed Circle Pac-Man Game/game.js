const canvas = document.getElementById('gameCanvas');
const context = canvas.getContext('2d');
const scoreboard = document.getElementById('scoreboard');

// Game settings
const numRings = 3;
const baseRadius = 200;
const ringSpacing = 40;
const pacmanRadius = 15;
const pacmanSpeed = 2; // Adjusted speed
const dotRadius = 5;
const dotsPerRing = 30;
const ghostRadius = 15;
const ghostSpeed = 1.5; // Adjusted speed
const pathWidth = 20;

// Game state
let pacmanRing = 0; // Index of the current ring Pac-Man is on
let pacmanAngle = 0;
let pacmanDirection = { x: 0, y: 0 }; // { x: 0, y: 0 } means no movement
let dots = [];
let ghosts = [
    { ring: 0, angle: 0, color: 'red' },
    { ring: 0, angle: Math.PI / 2, color: 'cyan' }
];
let score = 0;

// Initialize dots
for (let i = 0; i < numRings; i++) {
    dots.push([]);
    for (let j = 0; j < dotsPerRing; j++) {
        const angle = (j / dotsPerRing) * 2 * Math.PI;
        dots[i].push({ angle: angle, eaten: false });
    }
}

// Initialize joystick
const joystick = nipplejs.create({
    zone: document.getElementById('joystick-container'),
    mode: 'static',
    position: { left: '50%', top: '50%' },
    color: 'white'
});

joystick.on('move', (evt, data) => {
    if (data.direction) {
        const angle = data.angle.degree;
        if (angle >= 45 && angle < 135) {
            pacmanDirection = { x: 0, y: -1 }; // Up
        } else if (angle >= 135 && angle < 225) {
            pacmanDirection = { x: -1, y: 0 }; // Left
        } else if (angle >= 225 && angle < 315) {
            pacmanDirection = { x: 0, y: 1 }; // Down
        } else {
            pacmanDirection = { x: 1, y: 0 }; // Right
        }
    }
});

joystick.on('end', () => {
    pacmanDirection = { x: 0, y: 0 }; // Stop movement
});

// Game loop
function gameLoop() {
    update();
    draw();
    setTimeout(() => {
        requestAnimationFrame(gameLoop);
    }, 50); // Adjusted to normal speed
}

// Update game state
function update() {
    // Move Pac-Man
    if (pacmanDirection.x === 1) {
        pacmanAngle += pacmanSpeed * Math.PI / 180;
    } else if (pacmanDirection.x === -1) {
        pacmanAngle -= pacmanSpeed * Math.PI / 180;
    } else if (pacmanDirection.y === -1 && canMoveToRing(pacmanRing - 1)) {
        pacmanRing--;
        pacmanDirection = { x: 0, y: 0 };
    } else if (pacmanDirection.y === 1 && canMoveToRing(pacmanRing + 1)) {
        pacmanRing++;
        pacmanDirection = { x: 0, y: 0 };
    }

    // Move ghosts
    ghosts.forEach(ghost => {
        ghost.angle += ghostSpeed * Math.PI / 180;
    });

    // Check for dot collision
    dots[pacmanRing].forEach(dot => {
        if (!dot.eaten && Math.abs(dot.angle - pacmanAngle) < 0.1) {
            dot.eaten = true;
            score++;
            updateScore();
        }
    });

    // Check for ghost collision
    ghosts.forEach(ghost => {
        if (ghost.ring === pacmanRing && Math.abs(ghost.angle - pacmanAngle) < 0.2) {
            alert('Game Over! Final Score: ' + score);
            resetGame();
        }
    });
}

// Check if Pac-Man can move to the specified ring
function canMoveToRing(targetRing) {
    if (targetRing < 0 || targetRing >= numRings) {
        return false;
    }
    const pathAngles = [0, Math.PI]; // Angles where paths exist between rings
    return pathAngles.some(angle => Math.abs(pacmanAngle - angle) < 0.1);
}

// Draw game
function draw() {
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Draw rings
    for (let i = 0; i < numRings; i++) {
        const radius = baseRadius - i * ringSpacing;
        context.beginPath();
        context.arc(canvas.width / 2, canvas.height / 2, radius, 0, 2 * Math.PI);
        context.strokeStyle = 'blue';
        context.lineWidth = pathWidth;
        context.stroke();
    }

    // Draw connecting pathways
    for (let i = 0; i < numRings - 1; i++) {
        const innerRadius = baseRadius - i * ringSpacing;
        const outerRadius = baseRadius - (i + 1) * ringSpacing;
        context.beginPath();
        context.moveTo(canvas.width / 2 + innerRadius, canvas.height / 2);
        context.lineTo(canvas.width / 2 + outerRadius, canvas.height / 2);
        context.strokeStyle = 'blue';
        context.lineWidth = pathWidth;
        context.stroke();

        context.beginPath();
        context.moveTo(canvas.width / 2 - innerRadius, canvas.height / 2);
        context.lineTo(canvas.width / 2 - outerRadius, canvas.height / 2);
        context.strokeStyle = 'blue';
        context.lineWidth = pathWidth;
        context.stroke();
    }

    // Draw Pac-Man
    const pacmanX = canvas.width / 2 + (baseRadius - pacmanRing * ringSpacing) * Math.cos(pacmanAngle);
    const pacmanY = canvas.height / 2 + (baseRadius - pacmanRing * ringSpacing) * Math.sin(pacmanAngle);
    context.beginPath();
    context.arc(pacmanX, pacmanY, pacmanRadius, 0.2 * Math.PI, 1.8 * Math.PI);
    context.lineTo(pacmanX, pacmanY);
    context.fillStyle = 'yellow';
    context.fill();

    // Draw dots
    dots.forEach((ring, ringIndex) => {
        ring.forEach(dot => {
            if (!dot.eaten) {
                const dotX = canvas.width / 2 + (baseRadius - ringIndex * ringSpacing) * Math.cos(dot.angle);
                const dotY = canvas.height / 2 + (baseRadius - ringIndex * ringSpacing) * Math.sin(dot.angle);
                context.beginPath();
                context.arc(dotX, dotY, dotRadius, 0, 2 * Math.PI);
                context.fillStyle = 'white';
                context.fill();
            }
        });
    });

    // Draw ghosts
    ghosts.forEach(ghost => {
        const ghostX = canvas.width / 2 + (baseRadius - ghost.ring * ringSpacing) * Math.cos(ghost.angle);
        const ghostY = canvas.height / 2 + (baseRadius - ghost.ring * ringSpacing) * Math.sin(ghost.angle);
        context.beginPath();
        context.arc(ghostX, ghostY, ghostRadius, 0, 2 * Math.PI);
        context.fillStyle = ghost.color;
        context.fill();
    });
}

// Update scoreboard
function updateScore() {
    scoreboard.innerText = `Score: ${score}`;
}

// Reset game
function resetGame() {
    pacmanRing = 0;
    pacmanAngle = 0;
    pacmanDirection = { x: 0, y: 0 };
    score = 0;
    updateScore();

    dots.forEach(ring => {
        ring.forEach(dot => {
            dot.eaten = false;
        });
    });

    ghosts.forEach(ghost => {
        ghost.ring = 0;
        ghost.angle = Math.random() * 2 * Math.PI;
    });
}

// Start game
gameLoop();
