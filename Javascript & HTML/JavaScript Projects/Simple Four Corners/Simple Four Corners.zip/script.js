// No JavaScript needed for this basic functionality as the CSS handles the hover effect

