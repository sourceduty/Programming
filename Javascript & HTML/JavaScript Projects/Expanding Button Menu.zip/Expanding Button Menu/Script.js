document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('animatedButton');
    let colorIndex = 0;
    const colors = ['color1', 'color2', 'color3'];

    button.addEventListener('click', () => {
        button.classList.remove(colors[colorIndex]);
        colorIndex = (colorIndex + 1) % colors.length;
        button.classList.add(colors[colorIndex]);

        if (!button.classList.contains('expanded')) {
            button.classList.add('expanded');
            button.style.width = "200px";
            button.style.height = "auto";
            button.innerHTML = `
                <a href="#" class="menu-item">Item 1</a>
                <a href="#" class="menu-item">Item 2</a>
                <a href="#" class="menu-item">Item 3</a>
            `;
        } else {
            button.classList.remove('expanded');
            button.style.width = "auto";
            button.innerHTML = "Menu";
        }
    });
});
