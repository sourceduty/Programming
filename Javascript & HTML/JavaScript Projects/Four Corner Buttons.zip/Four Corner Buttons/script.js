function buttonClicked(message) {
    alert(message);
}
